# face-anonymizer-ptyhon

Face anonymizer using Python and OpenCV !

[![Watch the video](https://img.youtube.com/vi/DRMBqhrfxXg/0.jpg)](https://www.youtube.com/watch?v=DRMBqhrfxXg)

## data

You can download the data I used in this tutorial [here](https://drive.google.com/drive/folders/1xzA0qtD9XrxajjTvZvqi9StXzxVXB9n5?usp=share_link).
